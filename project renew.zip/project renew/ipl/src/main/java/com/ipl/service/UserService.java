package com.ipl.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ipl.model.User;
import com.ipl.repository.UserRepository;


@Service
public class UserService {
	@Autowired
	UserRepository userRepository;


	public List<User> getAllUsers() {
		// TODO Auto-generated method stub
		return userRepository.findAll();
	}
	public User getUserByUserName(String userName) {
		// TODO Auto-generated method stub
		return userRepository.findByUserName(userName);
	}
	public User save(User user) {
		// TODO Auto-generated method stub
		return userRepository.save(user);
	}

	public Optional<User> getUserById(long id) {
		// TODO Auto-generated method stub
		return userRepository.findById(id);
	}
	
	public User getByEmail(String email) {
	return	userRepository.findByEmail(email);
	}
	
	public User getByEmailAndPassword(String email, String password) {
		return userRepository.findByEmailAndPassword(email,password);
	}
	
//	public User getByNameEmailPassword(String email, String password, String userName) {
//		return userRepository.findByNameEmailPassword(userName, email,password);
//	}

}
