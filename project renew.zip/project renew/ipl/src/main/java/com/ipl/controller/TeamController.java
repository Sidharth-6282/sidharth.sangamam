package com.ipl.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.ipl.model.Team;
import com.ipl.service.TeamService;

import lombok.extern.slf4j.Slf4j;

@CrossOrigin
@Slf4j
@RestController
@RequestMapping("/team")
public class TeamController {
	@Autowired
	TeamService teamService;
	
	@GetMapping("/all")
	//@RequestMapping(value = "/all", method = RequestMethod.GET)
	List<Team> getAllTeams() {
	log.debug("reached team/all");
	return teamService.getAllTeams();
		
	}
	//--------------------------------------------------
	@GetMapping("/byName/{name}")
	Team getTeamByName(@PathVariable("name") String name) {
	log.debug("name reacived::"+name);
	return teamService.getByUserName(name);
	}
	//--------------------------------------------------
	@GetMapping("/{id}")
	Team getTeamById(@PathVariable long id) {
	log.debug("team reacived::"+id);
	return teamService.getById(id).get();		
	}
	//--------------------------------------------------
	//--------------------------------------------------
	@PostMapping("/save")
	void save(@RequestBody Team team) {
	log.debug("save or update ::"+team);
	 teamService.save(team);
		
	}
	
}
