package com.ipl.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ipl.model.Team;
import com.ipl.model.User;
import com.ipl.repository.TeamRepository;



@Service
public class TeamService {

	@Autowired
	TeamRepository teamRepository;
	
	public List<Team> getAllTeams(){
		// TODO Auto-generated method stub
		return teamRepository.findAll();
	}
	public Team getByUserName(String userName) {
		// TODO Auto-generated method stub
		return teamRepository.findByUserName(userName);
	}
	public void save(Team team) {
		// TODO Auto-generated method stub
		 teamRepository.save(team);
	}

	public Optional<Team> getById(long id) {
		// TODO Auto-generated method stub
		return teamRepository.findById(id);
	}
	
}
