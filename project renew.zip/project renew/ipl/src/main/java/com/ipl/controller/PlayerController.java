package com.ipl.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.ipl.model.Player;
import com.ipl.service.PlayerService;

import lombok.extern.slf4j.Slf4j;
@CrossOrigin
@Slf4j
@RestController
@RequestMapping("/player")
public class PlayerController {

	@Autowired
	PlayerService playerService;
	
	@GetMapping("/all")
	//@RequestMapping(value = "/all", method = RequestMethod.GET)
	List<Player> getAllusers() {
	log.debug("reached user/all");
	return playerService.getAllPlayers();
		
	}
	//--------------------------------------------------
	@GetMapping("/byName/{name}")
	Player getPlayerByName(@PathVariable("name") String playerName) {
	log.debug("name reacived::"+playerName);
	return playerService.getByPlayerName(playerName);	
	}
	//--------------------------------------------------
	@GetMapping("/{id}")
	Player getPlayerById(@PathVariable long id) {
	log.debug("user reacived::"+id);
	return playerService.getPlayerById(id).get();
		
	}
	//--------------------------------------------------
	//--------------------------------------------------
	@PostMapping("/")
	void save(@RequestBody Player player) {
	log.debug("save or update ::"+player);
	 playerService.save(player);
		
	}
	
}
