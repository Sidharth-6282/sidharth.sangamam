 package com.ipl.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.ipl.dto.BiddingPlayer;
import com.ipl.model.Player;
import com.ipl.model.Team;
import com.ipl.repository.PlayerRepository;
import com.ipl.repository.TeamRepository;


@CrossOrigin

@RequestMapping("/player")
@RestController
public class BiddingController {

	@Autowired
	private TeamRepository teamRepository;
	
	@Autowired
	private PlayerRepository playerRepository;
	
	
	@PostMapping("/bidding")
	public Player placeBid(@RequestBody BiddingPlayer bidding) {
		return playerRepository.save(bidding.getTeam());
	}
	
	@GetMapping("/teamPlayers")
	public List<Team> findAllPlayers(){
		return teamRepository.findAll();
	}
}
