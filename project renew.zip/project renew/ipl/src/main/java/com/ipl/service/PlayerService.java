package com.ipl.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ipl.model.Player;
import com.ipl.repository.PlayerRepository;

@Service
public class PlayerService {

	@Autowired
   PlayerRepository playerRepository;
	
	public List<Player> getAllPlayers() {
		// TODO Auto-generated method stub
		return playerRepository.findAll();
	}
	public Player getByPlayerName(String playerName) {
		// TODO Auto-generated method stub
		return playerRepository.findByPlayerName(playerName);
	}
	public void save(Player player) {
		// TODO Auto-generated method stub
		 playerRepository.save(player);
	}

	public Optional<Player> getPlayerById(long id) {
		// TODO Auto-generated method stub
		return playerRepository.findById(id);
	}
}
