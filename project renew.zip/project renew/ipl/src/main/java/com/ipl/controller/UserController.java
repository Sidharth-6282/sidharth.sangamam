package com.ipl.controller;

import java.util.List;
import java.util.Optional;

import javax.websocket.server.PathParam;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.ipl.model.User;
import com.ipl.repository.UserRepository;
import com.ipl.service.UserService;

import lombok.extern.slf4j.Slf4j;

@CrossOrigin(origins= "")
@Slf4j
@RestController
@RequestMapping("/user")
public class UserController {
	@Autowired
	UserService userService;
	
	//--------------------------------------------------
	@GetMapping("/all")
	//@RequestMapping(value = "/all", method = RequestMethod.GET)
	List<User> getAllusers() {
	log.debug("reached user/all");
	return userService.getAllUsers();
		
	}
	//--------------------------------------------------
	@GetMapping("/byName/{name}")
	User getUserByName(@PathVariable("name") String name) {
	log.debug("name reacived::"+name);
	return userService.getUserByUserName(name);	
	}
	//--------------------------------------------------
	@GetMapping("/{id}")
	User getUserById(@PathVariable long id) {
	log.debug("user reacived::"+id);
	return userService.getUserById(id).get();
		
	}
	//--------------------------------------------------
	//--------------------------------------------------
	@PostMapping("/register")
	
	public ResponseEntity<User>  save(@RequestBody User user) {
		return ResponseEntity.ok(userService.save(user));
		
	}
			
		
	
@PostMapping("/login")

	public User loginUser(@RequestBody User user) throws Exception {
		String tempEmail= user.getEmail();
		String tempPass= user.getPassword();
		User userObj = null;
		if(tempEmail != null && tempPass != null) {
		userObj=	userService.getByEmailAndPassword(tempEmail, tempPass);
		}
		if(userObj != null) {
			throw new Exception("USER DOES NOT EXIST");
			}
		return userObj;	
	}
	

}
