package com.ipl.dto;

import com.ipl.model.Team;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;

@Data
@AllArgsConstructor
@NoArgsConstructor

@ToString

public class BiddingPlayer {

	 private Team team;

}
