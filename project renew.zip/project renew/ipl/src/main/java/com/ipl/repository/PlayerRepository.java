package com.ipl.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;

import com.ipl.model.Player;
import com.ipl.model.Team;

public interface PlayerRepository extends JpaRepository<Player, Long>, JpaSpecificationExecutor<Player> {

	Player findByPlayerName(String playerName);

	Player save(Team team);

}
