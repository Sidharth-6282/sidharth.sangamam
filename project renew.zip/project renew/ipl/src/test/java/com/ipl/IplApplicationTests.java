package com.ipl;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class IplApplicationTests {

	@Test
	void contextLoads() {
	}

}
