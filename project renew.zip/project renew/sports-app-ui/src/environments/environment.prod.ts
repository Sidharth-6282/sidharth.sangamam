export const environment = {
  production: true,
  apiURL:'http://localhost:9090/shcs/api'
};
