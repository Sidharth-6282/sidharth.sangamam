import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders, HttpParams } from '@angular/common/http';
import { Observable } from 'rxjs';
import {environment} from '../../environments/environment'
import { RestApiErrorHandlerService } from './rest-api-error-handler.service';
import { map, catchError } from 'rxjs/operators'

@Injectable({
  providedIn: 'root'
})
export class RestApiService extends RestApiErrorHandlerService {
  private baseUrl = environment.apiURL;
  private headers = new HttpHeaders().set('Content-Type', 'application/json');
    /**--------------------------------------**/
        constructor(private httpClient: HttpClient) {
          super();
        }
    /**--------------------------------------**/
    get(url, params:HttpParams): Observable<Object> {
        return this.sendRequest(this.baseUrl + url, 'get', null, params)
            .pipe(
              map((res) => { return res as Object }),
              catchError(this.handleError)
          )
    }  
     /**--------------------------------------**/
    post(url, body): Observable<Object> {
        return this.sendRequest(this.baseUrl + url, 'post', body)
            .pipe(
              map((res) => { return res as Object }),
              catchError(this.handleError)
              );
    }
    /**--------------------------------------**/
    patch(url, body): Observable<Object> {
        return this.sendRequest(this.baseUrl + url, 'patch', body)
            .pipe(
              map((res) => { return res as Object }),
              catchError(this.handleError)
              );
    }
    /**--------------------------------------**/
    sendRequest(url, type, body, params = null): Observable<any> {
        return this.httpClient[type](url,{'params': params, 'headers': this.headers}, body);//.retry(3);
    }
    /**--------------------------------------**/
}
