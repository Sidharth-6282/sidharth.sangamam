import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-team',
  templateUrl: './team.component.html',
  styleUrls: ['./team.component.css']
})
export class TeamComponent implements OnInit {

  defaultColDef = {
    sortable: true,
    filter: true
  };

  columnDefs = [
    { headerName: 'Player Id ', field: 'id', editable: false },
    { headerName: 'Player Name', field: 'name', editable: true },
    { headerName: 'Bid Amount', field: 'bidAmount', editable: true }
      
  ];

  rowData = [
    { id: '1', name: 'Rohit Sharma', bidAmount: 35000 },
    { id: '2', name: 'Ravindra Jadeja', bidAmount: 32000 },
    { id: '3', name: 'Virat Kohli', bidAmount: 72000 }
];

  constructor() { }

  ngOnInit(): void {
  }

}
